import React from 'react';
import { Link } from 'react-router-dom';

function DashboardPage() {
  return (
    <div>
      <h1>لوحة التحكم</h1>
      <nav>
        <ul>
          <li><Link to="/products">المنتجات</Link></li>
          <li><Link to="/sales">المبيعات</Link></li>
        </ul>
      </nav>
      <div>
        {/* يمكن إضافة ملخصات: إجمالي المبيعات اليوم، عدد المنتجات، ... */}
      </div>
    </div>
  );
}

export default DashboardPage;
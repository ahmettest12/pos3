import React, { useState, useEffect } from 'react';
import axios from 'axios';
import AddProductForm from '../components/Products/AddProductForm';

function ProductsPage() {
  const [products, setProducts] = useState([]);
  const token = localStorage.getItem('token');

  const load = () => {
    axios.get('http://localhost:5000/api/products', {
      headers: { Authorization: `Bearer ${token}` }
    }).then(res => setProducts(res.data));
  };

  useEffect(load, []);

  return (
    <div>
      <h2>المنتجات</h2>
      <AddProductForm onProductAdded={load} />
      <ul>
        {products.map(p => (
          <li key={p.id}>{p.name} - {p.price} - {p.stock}</li>
        ))}
      </ul>
    </div>
  );
}

export default ProductsPage;
import { useLang } from "../i18n/useLang";

function LoginPage() {
  const { t, switchLang } = useLang();
  // ...
  return (
    <div>
      <button onClick={() => switchLang('ar')}>العربية</button>
      <button onClick={() => switchLang('en')}>English</button>
      <h2>{t('login')}</h2>
      {/* ... */}
    </div>
  );
}
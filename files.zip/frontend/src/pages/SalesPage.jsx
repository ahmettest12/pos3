import { addToQueue, useOfflineQueue } from '../hooks/useOfflineQueue';
import axios from 'axios';

function SalesPage() {
  // ...
  useOfflineQueue(async (sale) => {
    await axios.post('/api/sales', sale, {
      headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
    });
  });

  const handleSale = async (sale) => {
    if (navigator.onLine) {
      await axios.post('/api/sales', sale, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
    } else {
      addToQueue(sale);
      alert('تم حفظ العملية وسيتم إرسالها عند الاتصال بالإنترنت');
    }
  };

  // ...
}
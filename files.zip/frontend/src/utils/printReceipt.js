export function printReceipt(sale) {
  const printContent = `
    <div dir="rtl" style="font-family: monospace; text-align: right;">
      <h2>إيصال بيع</h2>
      <p>المنتج: ${sale.productName}</p>
      <p>الكمية: ${sale.quantity}</p>
      <p>الإجمالي: ${sale.total} ريال</p>
      <p>التاريخ: ${new Date(sale.date).toLocaleString('ar-EG')}</p>
      <hr/>
      <p>شكرًا لتسوقكم!</p>
    </div>
  `;
  const win = window.open('', '', 'width=300,height=400');
  win.document.write(printContent);
  win.print();
  win.close();
}
export async function askNotificationPermission() {
  if ('Notification' in window) {
    const permission = await Notification.requestPermission();
    if (permission === "granted") {
      new Notification("تم تفعيل الإشعارات للنظام!");
    }
  }
}
// مثال أساسي للطباعة عبر WebUSB (تجريبي)
export async function printThermal(text) {
  try {
    const device = await navigator.usb.requestDevice({ filters: [{ vendorId: 0x04b8 }] }); // عدّل الـ vendorId
    await device.open();
    await device.selectConfiguration(1);
    await device.claimInterface(0);
    const encoder = new TextEncoder();
    await device.transferOut(1, encoder.encode(text + "\n\n\n"));
    await device.close();
  } catch (e) {
    alert("فشل الطباعة: " + e.message);
  }
}
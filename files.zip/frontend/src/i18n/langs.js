export const LANGS = {
  ar: {
    login: "تسجيل الدخول",
    username: "اسم المستخدم",
    password: "كلمة المرور",
    submit: "دخول",
    // ...
  },
  en: {
    login: "Login",
    username: "Username",
    password: "Password",
    submit: "Submit",
    // ...
  }
};
import { useState } from "react";
import { LANGS } from "./langs";

export function useLang() {
  const [lang, setLang] = useState(localStorage.getItem("lang") || "ar");
  const t = (key) => LANGS[lang][key] || key;
  const switchLang = (l) => {
    setLang(l);
    localStorage.setItem("lang", l);
  };
  return { lang, t, switchLang };
}
import { useEffect } from 'react';

export function useOfflineQueue(processQueue) {
  // processQueue: دالة لمعالجة الطلبات المعلقة عند عودة الاتصال
  useEffect(() => {
    const syncQueue = async () => {
      if (navigator.onLine) {
        const queue = JSON.parse(localStorage.getItem('pos-queue') || '[]');
        for (const item of queue) {
          try {
            await processQueue(item);
          } catch (e) {
            // إذا فشلت العملية، أوقف المزامنة
            break;
          }
        }
        localStorage.removeItem('pos-queue');
      }
    };
    window.addEventListener('online', syncQueue);
    syncQueue();
    return () => window.removeEventListener('online', syncQueue);
  }, [processQueue]);
}

export function addToQueue(request) {
  const queue = JSON.parse(localStorage.getItem('pos-queue') || '[]');
  queue.push(request);
  localStorage.setItem('pos-queue', JSON.stringify(queue));
}
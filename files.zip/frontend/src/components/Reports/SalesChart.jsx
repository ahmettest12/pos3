import React, { useEffect, useRef } from "react";
import Chart from "chart.js/auto";

function SalesChart({ data }) {
  const canvasRef = useRef(null);

  useEffect(() => {
    if (!canvasRef.current) return;
    new Chart(canvasRef.current, {
      type: "bar",
      data: {
        labels: data.map((d) => d.date),
        datasets: [
          {
            label: "إجمالي المبيعات",
            data: data.map((d) => d.total),
            backgroundColor: "rgba(54, 162, 235, 0.6)",
          },
        ],
      },
    });
  }, [data]);

  return <canvas ref={canvasRef} />;
}

export default SalesChart;
import React, { useState } from "react";
export default function PrinterSettings({ onSave }) {
  const [printer, setPrinter] = useState("default");
  const [paperWidth, setPaperWidth] = useState(80);

  const handleSave = () => {
    localStorage.setItem("printerSettings", JSON.stringify({ printer, paperWidth }));
    if (onSave) onSave({ printer, paperWidth });
  };

  return (
    <div>
      <label>الطابعة:</label>
      <select value={printer} onChange={e => setPrinter(e.target.value)}>
        <option value="default">الافتراضية</option>
        {/* أضف خيارات حسب الطابعات المتوفرة */}
      </select>
      <label>عرض الورق (مم):</label>
      <input value={paperWidth} onChange={e => setPaperWidth(e.target.value)} type="number" />
      <button onClick={handleSave}>حفظ الإعدادات</button>
    </div>
  );
}
import React, { useRef, useEffect } from "react";
// استخدم مكتبة مثل html5-qrcode أو quaggaJS
import { Html5Qrcode } from "html5-qrcode";

function BarcodeScanner({ onScan }) {
  const ref = useRef(null);

  useEffect(() => {
    const qrcode = new Html5Qrcode("reader");
    qrcode.start(
      { facingMode: "environment" },
      { fps: 10, qrbox: 250 },
      (decodedText) => {
        onScan(decodedText);
        qrcode.stop();
      }
    );
    return () => qrcode.stop();
  }, []);

  return <div id="reader" ref={ref} style={{ width: 300, height: 300 }} />;
}

export default BarcodeScanner;
import React, { useState } from 'react';
import axios from 'axios';

function AddProductForm({ onProductAdded }) {
  const [name, setName] = useState('');
  const [barcode, setBarcode] = useState('');
  const [price, setPrice] = useState('');
  const [cost, setCost] = useState('');
  const [stock, setStock] = useState('');
  const token = localStorage.getItem('token');

  const handleSubmit = async (e) => {
    e.preventDefault();
    await axios.post('http://localhost:5000/api/products', {
      name, barcode, price: Number(price), cost: Number(cost), stock: Number(stock)
    }, {
      headers: { Authorization: `Bearer ${token}` }
    });
    setName(''); setBarcode(''); setPrice(''); setCost(''); setStock('');
    if (onProductAdded) onProductAdded();
  };

  return (
    <form onSubmit={handleSubmit}>
      <input placeholder="اسم المنتج" value={name} onChange={e => setName(e.target.value)} required />
      <input placeholder="الباركود" value={barcode} onChange={e => setBarcode(e.target.value)} />
      <input placeholder="السعر" type="number" value={price} onChange={e => setPrice(e.target.value)} required />
      <input placeholder="تكلفة الشراء" type="number" value={cost} onChange={e => setCost(e.target.value)} />
      <input placeholder="المخزون" type="number" value={stock} onChange={e => setStock(e.target.value)} required />
      <button type="submit">إضافة المنتج</button>
    </form>
  );
}

export default AddProductForm;
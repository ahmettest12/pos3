const rbac = require('../middlewares/rbac.middleware');

router.post('/', auth, rbac('product.create'), create);
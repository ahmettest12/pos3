const router = require('express').Router();
const auth = require('../middlewares/auth.middleware');
const rbac = require('../middlewares/rbac.middleware');
const userController = require('../controllers/user.controller');

router.use(auth);

router.get('/', rbac(['admin']), userController.getAll);
router.post('/', rbac(['admin']), userController.create);

module.exports = router;
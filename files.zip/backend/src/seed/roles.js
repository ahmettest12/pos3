// ملف تهيئة الأدوار والصلاحيات
const { Role } = require('../models');

async function seedRoles() {
  const roles = [
    { name: 'admin', description: 'مدير النظام' },
    { name: 'cashier', description: 'كاشير' },
    { name: 'viewer', description: 'مشاهدة فقط' },
  ];
  for (let role of roles) {
    await Role.findOrCreate({ where: { name: role.name }, defaults: role });
  }
  console.log('Roles seeded.');
}

seedRoles().then(() => process.exit());
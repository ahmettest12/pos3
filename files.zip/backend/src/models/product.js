module.exports = (sequelize, DataTypes) => {
  const Product = sequelize.define('Product', {
    // ...
    BranchId: { type: DataTypes.INTEGER, allowNull: true }
  });
  Product.associate = (models) => {
    Product.belongsTo(models.Branch);
    Product.belongsTo(models.Company);
  };
  return Product;
};
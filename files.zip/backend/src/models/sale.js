module.exports = (sequelize, DataTypes) => {
  const Sale = sequelize.define('Sale', {
    quantity: { type: DataTypes.INTEGER, allowNull: false },
    total: { type: DataTypes.FLOAT, allowNull: false },
    date: { type: DataTypes.DATE, defaultValue: DataTypes.NOW },
  });
  return Sale;
};
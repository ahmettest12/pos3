module.exports = (sequelize, DataTypes) => {
  const Coupon = sequelize.define('Coupon', {
    code: { type: DataTypes.STRING, unique: true, allowNull: false },
    discountType: { type: DataTypes.ENUM('percentage', 'fixed'), allowNull: false },
    value: { type: DataTypes.FLOAT, allowNull: false },
    validFrom: { type: DataTypes.DATE },
    validTo: { type: DataTypes.DATE }
  });
  return Coupon;
};
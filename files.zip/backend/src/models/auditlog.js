module.exports = (sequelize, DataTypes) => {
  const AuditLog = sequelize.define('AuditLog', {
    action: { type: DataTypes.STRING, allowNull: false }, // مثل product.create
    userId: { type: DataTypes.INTEGER, allowNull: false },
    details: { type: DataTypes.JSONB }, // تفاصيل العملية
    createdAt: { type: DataTypes.DATE, defaultValue: DataTypes.NOW }
  });
  return AuditLog;
};
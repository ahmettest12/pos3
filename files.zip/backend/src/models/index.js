const { Sequelize, DataTypes } = require('sequelize');

const sequelize = new Sequelize(process.env.DATABASE_URL, {
  dialect: 'postgres',
  logging: false,
});

const User = require('./user')(sequelize, DataTypes);
const Company = require('./company')(sequelize, DataTypes);
const Role = require('./role')(sequelize, DataTypes);
const Permission = require('./permission')(sequelize, DataTypes);
const Product = require('./product')(sequelize, DataTypes);
const Sale = require('./sale')(sequelize, DataTypes);
const Inventory = require('./inventory')(sequelize, DataTypes);

// العلاقات بين الجداول
Company.hasMany(User);
User.belongsTo(Company);

Role.hasMany(User);
User.belongsTo(Role);

Company.hasMany(Product);
Product.belongsTo(Company);

User.hasMany(Sale);
Sale.belongsTo(User);

Product.hasMany(Sale);
Sale.belongsTo(Product);

Product.hasMany(Inventory);
Inventory.belongsTo(Product);

module.exports = {
  sequelize,
  User,
  Company,
  Role,
  Permission,
  Product,
  Sale,
  Inventory,
};
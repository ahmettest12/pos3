module.exports = (sequelize, DataTypes) => {
  const Permission = sequelize.define('Permission', {
    key: { type: DataTypes.STRING, allowNull: false, unique: true }, // مثل "product.create"
    description: { type: DataTypes.STRING }
  });

  Permission.associate = (models) => {
    Permission.belongsToMany(models.Role, { through: 'RolePermissions' });
  };

  return Permission;
};
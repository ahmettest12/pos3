const jwt = require('jsonwebtoken');
const { User, Role } = require('../models');

module.exports = async (req, res, next) => {
  const authHeader = req.headers['authorization'];
  if (!authHeader) return res.sendStatus(401);
  const token = authHeader.split(' ')[1];

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded;
    // تحميل بيانات المستخدم إن لزم
    req.dbUser = await User.findByPk(decoded.userId, { include: [Role] });
    next();
  } catch (e) {
    res.sendStatus(403);
  }
};
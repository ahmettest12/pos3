module.exports = (permissionKey) => {
  return async (req, res, next) => {
    const role = req.dbUser?.Role;
    if (!role) return res.sendStatus(403);

    // أحضر الصلاحيات من قاعدة البيانات
    const permissions = await role.getPermissions();
    const has = permissions.some(p => p.key === permissionKey);
    if (has) return next();

    return res.status(403).json({ error: "لا تملك الصلاحية المطلوبة" });
  };
};
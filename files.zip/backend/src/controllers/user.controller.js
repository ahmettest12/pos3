const { User, Role } = require('../models');
const bcrypt = require('bcryptjs');

exports.getAll = async (req, res) => {
  const users = await User.findAll({ where: { CompanyId: req.user.companyId }, include: [Role] });
  res.json(users);
};

exports.create = async (req, res) => {
  const { username, password, email, roleId } = req.body;
  const hashedPassword = await bcrypt.hash(password, 10);
  const user = await User.create({
    username,
    password: hashedPassword,
    email,
    RoleId: roleId,
    CompanyId: req.user.companyId,
  });
  res.status(201).json(user);
};

// تعديل/حذف ...الخ
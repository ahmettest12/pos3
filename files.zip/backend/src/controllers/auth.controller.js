function isStrongPassword(pw) {
  return pw.length >= 8 && /\d/.test(pw) && /[a-z]/i.test(pw) && /[A-Z]/.test(pw);
}

exports.register = async (req, res) => {
  const { password } = req.body;
  if (!isStrongPassword(password))
    return res.status(400).json({ error: 'كلمة المرور يجب أن تحتوي على حرف كبير وصغير ورقم وطول 8 أحرف على الأقل.' });
  // ...باقي الكود
};
exports.create = async (req, res) => {
  // ...كود البيع
  const company = await Company.findByPk(req.user.companyId);
  res.status(201).json({
    sale: { ... },
    currency: company.currency
  });
};
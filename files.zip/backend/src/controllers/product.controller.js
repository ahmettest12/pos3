const { Product } = require('../models');

exports.getAll = async (req, res) => {
  const products = await Product.findAll({ where: { CompanyId: req.user.companyId } });
  res.json(products);
};

exports.create = async (req, res) => {
  const { name, barcode, price, cost, stock } = req.body;
  const product = await Product.create({
    name,
    barcode,
    price,
    cost,
    stock,
    CompanyId: req.user.companyId,
  });
  res.status(201).json(product);
};
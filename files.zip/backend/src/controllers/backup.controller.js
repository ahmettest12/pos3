exports.restore = (req, res) => {
  // req.file يحمل ملف SQL المرفوع
  const sql = req.file.buffer.toString();
  exec(`psql -U postgres posdb`, { input: sql }, (err) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ message: "تمت الاستعادة بنجاح" });
  });
};
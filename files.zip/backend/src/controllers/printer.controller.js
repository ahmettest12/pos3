// هنا واجهة بسيطة للطباعة، يمكن التوسع عبر مكتبة escpos لاحقاً
exports.printReceipt = (req, res) => {
  const { sale } = req.body;
  // send sale data to the actual printer logic (USB/Network)
  // هنا مجرد محاكاة
  console.log('Printing:', sale);
  res.json({ status: 'printed' });
};
const { AuditLog } = require('../models');
exports.logAction = async (action, userId, details = {}) => {
  await AuditLog.create({ action, userId, details });
};